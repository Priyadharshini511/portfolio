
import { createRoot } from 'react-dom/client'
// import './index.css'
import App from './App.jsx'
// import MyContext from './ContextApi.jsx'
import './App.css'
// import Header from './Header.jsx'
import { Provider } from 'react-redux'
import store from '../reduxStore/store.js'

// let data = "global data"
// let data1 = "global data1"
createRoot(document.getElementById('root')).render(
    <Provider store={store}>
  <App/>
    </Provider>
  
    
    
)

//render appends everything 
{/* <MyContext.Provider value={{data,data1}}>
    <App/>
</MyContext.Provider> */}