import React from 'react';

function Header() {
//   function curry(a) {
//     console.log("currying");
    
//     // Curried function implementation
//     const curried = (b) => a + b;
//     console.log(curried(40)); // Example of using the curried function
//   }

//   curry(10); // Call the function with an initial value

// function greet(greeting,symbol){
//    return `${greeting} ${this.name} ${this.age} ${symbol}`
// }

// const user={name:"john",age:27}
// console.log(greet.call(user,"hello","!"))

// function greet() {
//     const { name, age } = this; // Destructure name and age from this
//     console.log(name, age);
//   }
  
//   const user = { name: "priya", age: 27 };
  
//   // Use .call() to explicitly set this to user when calling greet
//   greet.call(user);


//immediate function
(function ayhello(){
    console.log("hello");
    
})()
  


  return (
    <div>header</div>
  );
}

export default Header;
