

// // function App() {
// //   // const [count, setCount] = useState(0)
// //   //  let data = "the parent data"
// //   function getData(data) {
// //     console.log(data);
// //   }
// //   return (
// //     <>
// //       {/* <Header /> */}
// //       <Content pData={getData} />
// //       {/* <Content />
// //       <Component1/>
// //       <Component2/>
// //       <Component3/>
// //       <Component4/>
// //       <Component5/>
// //       <Footer /> */}
// //     </>

// //   )
// // }

// // export default App

// // //fragments are empty tags
// // //all the tags must be wrapped using any tag or fragments 

// // import React, { useState } from "react";
// // import Content from "./Content";
// // import Footer from "./Footer";

// // function App() {
// //     const [data, setData] = useState(""); // State to hold data from the child

// //     function getData(cData) {
// //         console.log(cData); // Logs the data from the child
// //         setData(cData); // Updates the state with the received data
// //     }

// //     return (
// //         <div>
// //             <Content pData={getData} /> {/* Passes `getData` to Content */}
// //             <Footer pData={data} /> {/* Passes received data to Footer */}
// //         </div>
// //     );
// // }

// // export default App;

// // import { useState } from 'react'
// import './App.css'
//  import Header from './Header'
// // import Footer from './Footer'
// // import Content from './Content'
// // import ApiCall from './ApiCall'
// // import Todo from './Todo'
// // import Site from './Site'
// // import { BrowserRouter, Routes, Route } from 'react-router-dom'
// // import Home from './Home'
// // import Contact from './Contact'
// // import About from './About'
// // import OldBook from './OldBook'
// // import NewBook from './NewBook'
// // import User from './User'
// // import { Link } from 'react-router-dom'
// // import Header from './Header'

// // import { Component1, Component2, Component3, Component4, Component5 } from './Component'

// function App() {
//   return (
//     <>
//     <Header/>
// {/*      
//       {/* <Footer/> */}
//       {/* <ApiCall/> */}
//       {/* <Todo/> */}
//       {/* <Site/> */}
//       <BrowserRouter>
//       <ul>
//         <li>
//           <Link to="/home">Home</Link>
//         </li>
//         <li>
//           <Link to="/about">About</Link>
//         </li>
//         <li>
//           <Link to="/contact">Contact</Link>
//         </li>

//       </ul>
//         <Routes>
//           <Route path='/home' element={<Home />} />
//           <Route path='/about' element={<About />} />
//           <Route path='/contact' element={<Contact />} />
//           <Route path='/books'>
//             <Route path='newbooks' element={<NewBook />} />
//             <Route path='oldbooks' element={<OldBook />} />
//           </Route>
//           <Route path='/user/:id' element={<User />} />

//         </Routes>
//       </BrowserRouter>
//       <Home/> */}
//     </>
//   )
// }

// export default App

import React from 'react'

import Counter from './counter/Counter'
function App() {
  return (
    <div>
    <Counter/>
    </div>

    
    
  )
}

export default App