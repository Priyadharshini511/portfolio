// import React from 'react';
// import { decrement, increment, reset } from '../../slice/CounterSlice';
// import { useSelector, useDispatch } from 'react-redux';

// function Counter() {
//   const selector = useSelector((state)=>state.counter); // Access the `count` from Redux state
//   console.log(selector);
  
//   const dispatch = useDispatch(); 
//   // Dispatch function to trigger actions

//   return (
//     <div>
//     <div>{selector.Counter}</div>
//     <button onClick={()=>dispatch(increment())}>Increment</button>
//     <button onClick={()=>dispatch(decrement())}>Decrement</button>
//     <button onClick={()=>dispatch(reset())}>reset</button>
// </div>


//   );
// }

// export default Counter;

import React, { useState } from 'react';
import { addValue, decrement, increment, reset } from '../../slice/CounterSlice';
import { useSelector, useDispatch } from 'react-redux';

function Counter() {
  const count = useSelector((state) => state.counter.count); // Access the count from Redux state
  console.log(count); // Debugging: Verify the count value in the console

  const dispatch = useDispatch(); // Dispatch function to trigger actions

  // Local state for storing the input value
  const [inputValue, setInputValue] = useState('');

  // Function to handle the submit action
  const handleSubmit = () => {
    // Convert input value to a number and ensure it's a valid number
    const numberToAdd = parseInt(inputValue);
    if (!isNaN(numberToAdd)) {
      // Dispatch the increment action with the input value added to the count
      dispatch(increment(numberToAdd));
      setInputValue(''); // Reset the input field
    } else {
      alert('Please enter a valid number');
    }
  };
  function handleclick1(){
    userValue = Number.parseInt(prompt("enter the inc: "))
    dispatch(addValue(userValue))
  }

  return (
    <div>
      {/* Displaying the current count */}
      <h1>Counter: {count}</h1>

      {/* Buttons */}
      <div>
        <button onClick={() => dispatch(increment())}>Increment</button>
        <button onClick={() => dispatch(decrement())}>Decrement</button>
        <button onClick={() => dispatch(reset())}>Reset</button>
        <button onClick={handleclick1}>add value</button>
        
      </div>

      {/* Text box to input the number */}
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)} // Update the input value on change
        placeholder="Enter a number"
      />

      {/* Submit button to add the input value to the counter */}
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}

export default Counter;

