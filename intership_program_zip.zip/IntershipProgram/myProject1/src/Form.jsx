import React, { useState } from 'react'

function Form() {
  const [data,setData]=useState({email:"example@gmail.com",password:""})
  function handleChange(e){
setData({...data,email:e.target.value});

  }
  console.log(data);
  
  return (
    <div className='h-50 bg-blue-200 flex justify-center min-h-screen'>
        <form className= 'bg-white h-80 p-6 rounded-lg w-full max-w-sm'>
          <h2 className='text-2xl font-bold text-blue-500 text-center mb-4'>Login Page</h2>
          <div className='mb-4'>
          <label htmlFor='email' className=' block text-lg font-medium mb-1'>Email</label>
<input value={data.email} onChange={(e)=>handleChange(e)} type='text' id = 'email' className='w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 '/>

          </div>
          <div className='mb-4'>
          <label htmlFor='password' className='block text-lg font-medium mb-1'>Password</label>
          <input onChange={(e)=>setData({...data,password:e.target.value})} type='password' id='password' className='w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500'/>
          </div>
          
<button className='w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500'>Login</button>

        </form>
    </div>
  )
}

export default Form


