import React, { useState, useRef } from 'react';

function Todo() {
    const [data, setData] = useState([]);
    const refer = useRef();

    function handleClick() {

        setData([...data, { task: refer.current.value }]);
        refer.current.value = ""; 
    }

    function handleDelete(index) {

        setData(data.filter((_, i) => i !== index));
    }

    return (
        <div>
            <input ref={refer} type="text" placeholder="Enter your task" />
            <button onClick={handleClick}>Save</button>
            <ul>
                {data.map((item, index) => (
                    <li key={index}>
                        {item.task}
                        <button onClick={() => handleDelete(index)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default Todo;

//axios used to call api
//all npm packeages available in npm 