import React from 'react'
export function Component1() {
  return (
    <div>component 1 </div>
  )
};

export function Component2() {
  return (
    <div>component 2</div>
  )
};

export function Component3() {
  return (
    <div>
        component 3
    </div>
  )
};


export function Component4() {
  return (
    <div>component 4</div>
  )
};

export function Component5() {
    return (
      <div>component 5</div>
    )
  };


//export {Component1,Component2,Component3,Component4,Component5}