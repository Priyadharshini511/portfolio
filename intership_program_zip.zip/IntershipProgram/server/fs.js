const fs=require("fs")

// fs.writeFile("sample.txt","created a sample file using fs ",(err)=>{})
// fs.appendFile("sample.txt","\n this msg is appened",(err)=>{})
// fs.readFile("sample.txt",(err,data)=>{console.log(data)});
// fs.readFile("sample.txt",(err,data)=>{console.log(data.toString())});   //to read file
// fs.unlink("sample.txt",()=>{})
// fs.writeFile("sample.txt","created a sample file using fs ",(err)=>
//     {if(err){
//         console.log(err);   
//     }
// })
// try{
//     fs.readFile("sample.tt",(err,data)=>{
//         if(err) throw err 
//         console.log(data.toString())
//     });
// } catch (error) {
//     console.log(error.message)
// }
// fs.readFile("sample.txt",(err,data)=>{
//             if(err) throw err 
//              console.log(data.toString())
//          });
// process.on("uncaughtException",(err)=>{
//     console.log(err.message);
    
// }) 

// fs.mkdir("folder",()=>{})
// fs.rmdir("folder",()=>{})

    // fs.readFile("sample1.txt", "utf-8", (err, data) =>{console.log(data.toString())}); 
//    const fileDATA = fs.readFileSync("sample1.txt","utf-8")
//    console.log(fileDATA);
//     console.log("outside")

// fs.writeFile("old.txt","thi is old file",()=>{
//     fs.appendFile("old.txt","appened data",()=>{
//         fs.readFile("old.txt","utf-8",(err,data)=>{console.log(data)
//         })
//     })
// })


// const data1 = fs.writeFile("new.txt","",()=>{})

fs.writeFileSync("old.txt", "this is old file");
fs.appendFileSync("old.txt", " appened data");
const data = fs.readFileSync("old.txt", "utf-8");
console.log(data);

///task 

