const http = require("http");
const fs = require("fs");
const path = require("path");
const url = require("url");
const data = fs.readFileSync(path.join(__dirname, "templates", "template.html"), "utf8");
const data1 = fs.readFileSync(path.join(__dirname, "templates", "product.html"), "utf8");
const jsonData = JSON.parse(fs.readFileSync("product.json", "utf-8"));
let productHtmlArray = jsonData.map((prod) => {
    let output = data1.replace("{{%IMAGE%}}", prod.productImage);
    output = output.replace("{{%NAME%}}", prod.name);
    output = output.replace("{{%MODNAME%}}", prod.modeName);
    output = output.replace("{{%MODNUMBER%}}", prod.modelNumber);
    output = output.replace("{{%SIZE%}}", prod.size);
    output = output.replace("{{%TYPE%}}", prod.camera);
    output = output.replace("{{%COLOR%}}", prod.color);
    output = output.replace("{{%PRICE%}}", prod.price);
    output = output.replace("{{%ID%}}", prod.id);
   
    return output;
});
function renderProduct(prod) {
    let output = data1.replace("{{%IMAGE%}}", prod.productImage)
  output = output.replace("{{%MODNAME%}}", prod.modeName)
  output = output.replace("{{%NAME%}}", prod.name)
  output = output.replace("{{%%MODNUMBER%%}}", prod.modelNumber)
  output = output.replace("{{%SIZE%}}", prod.size)
  output = output.replace("{{%TYPE%}}", prod.camera)
  output = output.replace("{{%PRICE%}}", prod.price)
  output = output.replace("{{%COLOR%}}", prod.color)
  output = output.replace("{{%ID%}}", prod.id)
  return output;
}
productHtmlArray = productHtmlArray.join("");

const server = http.createServer((req, res) => {
  let path = req.url

   path = path.toLowerCase()
     let { query, pathname } = url.parse(req.url, true)
     pathname = pathname.toLowerCase()
     console.log(pathname);

     
    if (path=== "/Home" || path === "/") {
        res.end(data.replace("{{%CONTENT%}}", "You are at home"));
    } else if (path === "/Contact") {
        res.end(data.replace("{{%CONTENT%}}", "You are at contact"));
    } else if (path === "/About") {
        res.end(data.replace("{{%CONTENT%}}", "You are at about"));
    }else if (pathname === "/products") {
        console.log(path.indexOf("/products"));
    
        if (query.id) {
    let id=query.id*1
    
    
          let findOne = jsonData.find(item => item.id === id)
         res.end(data.replace("{{%CONTENT%}}",renderProduct(findOne)))
          
        }
        else {
    
          res.end(data.replace("{{%CONTENT%}}", productHtmlArry))
        }
    
    
      }
      else res.end("404")
    
    })

server.listen(5000, () => {
    console.log("Server running on http://localhost:5000");
});