//readline module

// const readline = require("readline");

// const r1 = readline.createInterface({
//   input: process.stdin,
//   output: process.stdout
// });
// let variable="fbenfsc "
// r1.question("Enter your name: ", (data) => {
//   console.log("Hello,", data);
// });
// console.log(variable)

//      os module

// const os = require("os")
// console.log(os.homedir());   //home directory
// console.log(os.tmpdir());  //temp directory
// console.log(os.cpus());   //total cpus
// console.log(os.arch());  //architectre(32,64)
// console.log(os.platform());   //platform(windows,)
// console.log(os.hostname());  //name 
// console.log(os.freemem());     //free space
// console.log(os.totalmem());     //total space
// console.log(os.version());    // windows version

//      path module

// const path = require("path");
// console.log(__dirname);
// console.log(__filename);
// console.log(path.basename("C:\Users\Admin\Documents\SEMESTER 4\FullStack Intership\server\index.js"));
// console.log(path.extname("sample.txt"));
// console.log(path.join("folder","index.js"));
// console.log(path.parse("c:index.js"));

// http    request,response

const http = require("http")

const server = http.createServer((req,res)=>{
    console.log(req)
  res.end("hello ")
    
})
server.listen(3000,()=>console.log("server is running"))
