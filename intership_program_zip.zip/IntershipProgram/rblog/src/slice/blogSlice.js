import { createSlice } from "@reduxjs/toolkit";

const initialState = [
  {
    id: 1,
    author: "Smith",
    data: "lorem ipsum .....",
  },
  {
    id: 2,
    author: "Smith",
    data: "lorem ipsum .....",
  },
  {
    id: 3,
    author: "Smith",
    data: "lorem ipsum .....",
  },
  {
    id: 4,
    author: "Smith",
    data: "lorem ipsum .....",
  },
];

const post = createSlice({
  name: "post",
  initialState,
  reducers: {
    addPost: (state, action) => {
      const newPost = {
        id: state.length + 1, // Incremental ID
        author: action.payload.author,
        data: action.payload.data,
      };
      state.unshift(newPost); // Add the new post at the beginning
    },
  },
});

export const { addPost } = post.actions; // Export the action creator
export default post.reducer;
