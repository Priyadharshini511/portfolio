// postsSlice.js
import { createSlice } from '@reduxjs/toolkit';

const postsSlice = createSlice({
    name: 'posts',
    initialState: [],
    reducers: {
        addPost: (state, action) => {
            state.unshift(action.payload); // Add post at the beginning
        },
    },
});

export const { addPost } = postsSlice.actions;
export default postsSlice.reducer;
