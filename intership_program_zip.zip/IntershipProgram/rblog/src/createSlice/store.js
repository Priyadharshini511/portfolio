// import { configureStore } from "@reduxjs/toolkit";
// import post from '../slice/blogSlice'; // Existing slice
// import postsReducer from '../slice/postsSlice'; // Import the newly created postsSlice

// const store = configureStore({
//     reducer: {
//         post: post, // Existing reducer
//         posts: postsReducer, // Newly added reducer
//     },
// });

// export default store;

// store.js
import { configureStore } from '@reduxjs/toolkit';
import postsReducer from '../slice/postsSlice';  // Ensure correct import path

const store = configureStore({
    reducer: {
        posts: postsReducer,  // Make sure the slice reducer is assigned to 'posts'
    },
});

export default store;

