// import React from 'react'
// import { useSelector } from 'react-redux'
// import { useDispatch } from 'react-redux'

// function ViewPost1() {
//     const posts = useSelector((state) => state.posts); // Access posts from the Redux store

//     return (
//         <div>
//             <h2>Posts</h2>
//             {posts.length > 0 ? (
//                 posts.map((post, index) => (
//                     <div key={index} style={{ border: '1px solid black', margin: '10px', padding: '10px' }}>
//                         <p><strong>Author:</strong> {post.author}</p>
//                         <p><strong>Data:</strong> {post.data}</p>
//                     </div>
//                 ))
//             ) : (
//                 <p>No posts available.</p>
//             )}
//         </div>
//     );
// }

// export default ViewPost1

// ViewPost1.jsx
import React from 'react';
import { useSelector } from 'react-redux';

function ViewPost1() {
    const posts = useSelector((state) => state.post); // Get posts from Redux

    return (
      <div>
        <h2>Posts</h2>
        {posts.length === 0 ? (
          <p>No posts available.</p>
        ) : (
          posts.map((post) => (
            <div key={post.id}>
              <h3>{post.author}</h3>
              <p>{post.data}</p>
            </div>
          ))
        )}
      </div>
    );
}

export default ViewPost1;

