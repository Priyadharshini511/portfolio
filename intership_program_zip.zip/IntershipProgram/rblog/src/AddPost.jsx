import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addPost } from './slice/postsSlice'

function AddPost() {
    const [author, setAuthor] = useState('');
    const [data, setData] = useState('');
    const dispatch = useDispatch();

    const handleAddPost = () => {
        if (author && data) {
            // Dispatch the addPost action
            dispatch(addPost({ author, data }));
            // Clear the inputs
            setAuthor('');
            setData('');
        } else {
            alert('Please provide both author and data.');
        }
    };

    return (
        <div>
            <h2>Add a New Post</h2>
            <label htmlFor="author">Author: </label>
            <input
                type="text"
                id="author"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
            />
            <br />
            <label htmlFor="data">Data: </label>
            <input
                type="text"
                id="data"
                value={data}
                onChange={(e) => setData(e.target.value)}
            />
            <br />
            <button onClick={handleAddPost}>Add Post</button>
        </div>
    );
}

export default AddPost;
