// // // import React, { useState } from 'react';

// // // function CreatePost() {
// // //     const [author, setAuthor] = useState("");
// // //     const [data, setData] = useState("");

// // //     return (
// // //         <div>
// // //             <label htmlFor="author">Author: </label>
// // //             <input
// // //                 type="text"
// // //                 id="author"
// // //                 value={author}
// // //                 onChange={(e) => setAuthor(e.target.value)}
// // //             />
// // //             <br />
// // //             <label htmlFor="data">Data: </label>
// // //             <input
// // //                 type="text"
// // //                 id="data"
// // //                 value={data}
// // //                 onChange={(e) => setData(e.target.value)}
// // //             />
// // //             <br />
// // //             <button onClick={() => console.log({ author, data })}>Submit</button>
// // //         </div>
// // //     );
// // // }

// // // export default CreatePost;

// // import React, { useState } from 'react';
// // import { useDispatch } from 'react-redux';
// // import { addPost } from './slice/postsSlice';

// // function CreatePost() {
// //     const [author, setAuthor] = useState('');
// //     const [data, setData] = useState('');
// //     const dispatch = useDispatch();

// //     const handleSubmit = () => {
// //         if (author && data) {
// //             // Dispatch the addPost action with the new post data
// //             dispatch(addPost({ author, data }));
// //             // Clear input fields
// //             setAuthor('');
// //             setData('');
// //         } else {
// //             alert('Please fill out both fields.');
// //         }
// //     };

// //     return (
// //         <div>
// //             <label htmlFor="author">Author: </label>
// //             <input
// //                 type="text"
// //                 id="author"
// //                 value={author}
// //                 onChange={(e) => setAuthor(e.target.value)}
// //             />
// //             <br />
// //             <label htmlFor="data">Data: </label>
// //             <input
// //                 type="text"
// //                 id="data"
// //                 value={data}
// //                 onChange={(e) => setData(e.target.value)}
// //             />
// //             <br />
// //             <button onClick={handleSubmit}>Submit</button>
// //         </div>
// //     );
// // }

// // export default CreatePost;

// // CreatePost.jsx
// // CreatePost.jsx
// import React, { useState } from 'react';
// import { useDispatch } from 'react-redux';
// import { addPost } from './slice/postsSlice';  // Ensure this import is correct

// function CreatePost() {
//     const [author, setAuthor] = useState('');
//     const [data, setData] = useState('');
//     const dispatch = useDispatch();

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         if (author && data) {
//             // Dispatching the action to add the post to the store
//             dispatch(addPost({ author, data }));
//             setAuthor('');
//             setData('');
//         } else {
//             alert('Please provide both author and data.');
//         }
//     };

//     return (
//         <form onSubmit={handleSubmit}>
//             <h2>Create a New Post</h2>
//             <label htmlFor="author">Author: </label>
//             <input
//                 type="text"
//                 id="author"
//                 value={author}
//                 onChange={(e) => setAuthor(e.target.value)}
//             />
//             <br />
//             <label htmlFor="data">Data: </label>
//             <input
//                 type="text"
//                 id="data"
//                 value={data}
//                 onChange={(e) => setData(e.target.value)}
//             />
//             <br />
//             <button type="submit">Add Post</button>
//         </form>
//     );
// }

import React, { useState } from "react";
import { useDispatch } from "react-redux";
import AddPost from "./AddPost"; // Import the addPost action
import { useNavigate } from "react-router-dom"; // For navigation

function CreatePost() {
  const [author, setAuthor] = useState("");
  const [data, setData] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmit = () => {
    if (author.trim() && data.trim()) {
      // Dispatch addPost with the new post data
      dispatch(addPost({ author, data }));

      // Clear the form
      setAuthor("");
      setData("");

      // Redirect to the posts page to view the new post
      navigate("/posts");
    } else {
      alert("Please fill in both fields.");
    }
  };

  return (
    <div>
      <h2>Create Post</h2>
      <label>Author</label>
      <input
        type="text"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        placeholder="Enter author"
      />
      <label>Post Content</label>
      <input
        type="text"
        value={data}
        onChange={(e) => setData(e.target.value)}
        placeholder="Enter post content"
      />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}

export default CreatePost;






