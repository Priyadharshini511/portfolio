// import React from 'react';
// import './App.css';
// import { BrowserRouter, Routes, Route } from 'react-router-dom';
// import ViewPost1 from './ViewPost1';
// import AddPost from './AddPost';
// import CreatePost from './CreatePost';
// import Home from './Home';
// function App() {
//     return (
//       <BrowserRouter>
//       <Routes>
//           <Route path="/" element={<Home />} />
//           <Route path="/posts" element={<ViewPost1 />} />
//           <Route path="/create" element={<CreatePost />} />
//           <Route path="/add" element={<AddPost />} />
//       </Routes>
//   </BrowserRouter>
  
//     );
// }

// export default App;

import { BrowserRouter, Routes, Route } from "react-router-dom";
import ViewPost1 from "./ViewPost1";
import CreatePost from "./CreatePost";
import Home from "./Home"; // Import the Home component
import "./App.css";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} /> {/* Add this route */}
        <Route path="/posts" element={<ViewPost1 />} />
        <Route path="/create" element={<CreatePost />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;


